package series;

public class sqaure{


		public sqaure(int n)
		{

					for(int i=1;i<=n;i++)
					{ 
					System.out.println(" "+i*i);
					}
		}

}